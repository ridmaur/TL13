# Using Adobe Campaign Standard with Adobe I/O
In this exercise we are going to create the same account in Adobe Campaign Standard, using the CRM Id we retrieved from Hubspot. Such a CRM Id is typically used in the connection between customer information and marketing automation.

## Objective
The objective of this exercise is to understand how Adobe I/O runtime can work with Adobe solutions and also understand how more complex functions can be deployed in Adobe I/O runtime.

## Setup
First make sure you have all the details configured in the config.js file. You can find this information in the Adobe IO console. The private key is one string where each enter is recplaced with '\n'. After that, execute the following commands in the terminal:
$ zip -r action.zip .
$ wsk action create adobecampaignstandard index.js --web true -v
or for an update
$ wsk action update adobecampaignstandard --kind nodejs:6 --web true action.zip 

In my case, I have extended the profile with a Cmrid. This allows me to retrieve a profile on Crmid (/campaign/profileAndServicesExt/profile/byCrmid?_parameter=)

## Usage
You can run the function using the browser or via the command line. The easiest way is to use a browser. For a get profile run the following url:
https://runtime-preview.adobe.io/api/v1/web/patrickburggraaf/default/adobecampaignstandard.json?action=get&cid=<your customer id>

for an update run the following url
https://runtime-preview.adobe.io/api/v1/web/patrickburggraaf/default/adobecampaignstandard.json?action=update&cid=103&middleName=van&...

You can extend the profile attributes in the app.js.

## Questions
Please reach out to Patrick Burggraaf (burggraa@adobe.com) for questions# voiceEI
