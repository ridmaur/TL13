module.exports = {
    campaign: {
        campaignClientID : "d2c09ac767024e39ad463c6194169520",
        campaignClientSecret : "59d287ae-b51d-45ac-9892-09b6f8fc025c",
        campaignOrgID : "B5BA1225524F6CEC0A490D4D@AdobeOrg",
        campaignTechnicalAccount : "D79B36525AA4FAF00A495C6C@techacct.adobe.com",
        campaignPEM : "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAucQysZ86bbN8qm1v/BumbV5g+9DUW0g/kWXfu0TLmwye3kiY\n8xxnBa0BjMKI+ggXOas5bFv/ikwK+Yl630nlqbIcHZC0myLoeCG/cRaBOnZD2xyy\nfWGKOvHIFWdfp6XWjqrdskDRb7mpw1RNPv6aU3PBN8woJr0xhu7ZILXnqp0e+mGP\naOvwyIGZdQMa0xm3oid4dzJ0okci5kruQy41uS/62lk9rY7S3sJV96RQ6O1hDihj\nzQQ+gyIfXdop+hVfJOAoiFW0nivdDf0ytHziMT1T6iXPqiHJcziG5zNdJeYkEhFV\np8zLIR5/3oPeVP4A1emk/Z6BgySp5mp3+kPXaQIDAQABAoIBACIzjynIqRc9bnxq\nPa3q4U9NiwmRvyc3PAzm9rQhzGK1hiJit1Y7KnSPD7P8tP9jsfL6JU5f+cJakcKz\nnx2xG0mM80Q2Oio92RMVE4wcmppK399dfzc6WBrWHQJjz+arz77gkoSZDnZFdo3x\n3W71rTAkJbTCL7pCJvYyz2MIWqi8h/ZIor5ljaXr7kJS0laJOXMTUiaCcuX9wVNH\nu0aioocWfpnKoBBh7IIccLtQXSzWhF1xj6TfGREe38i/58XOf8OmsfvjnK9YG/Rw\nXjt3MuisT8JhLT6HqAXAnPfxm44HXGBdFTFD1C0MopD7qW+6IHwMm/83iS/5oX3t\nWC5EzSECgYEA9UwU+2obK86Axcv3irMIIoD2rB5ixGAgFDd6cZvoZT9JJcIFSlW1\nF6xV9dsNH72ZNeGuQMGoTCKtCTnRbLTblUCIfr9LRqJevq7/aT8u9MebtcsME0Y2\nokF2srpkE1fFzFTULYMZvrJXBTUl1FO8JrK0ARNp9PX+gTkt02ce+M0CgYEAwd8r\nanlFi32ZB/mlPgfOXleIA9pup/l+L/iVXZWfUuwGiWNS72r8+XIjVHKfPnfB9eDc\n0EpQfbkaDEMEW4173co8eKKa0WJuNdM1ko2Wm4/AwSgedDevGSlXhKSr6NpT4/yw\nKRHLgIL10w7nxMRKNPvEC6AgbVSyB8IC7mq6CQ0CgYEAneeYKjAnxY9tfebLN1IA\njpWONUZqNhfbDqiX/cJrW6HdqJy5YxzBMrgRre6RCDm5AuKAldcUS86WrTW3Bs91\n+yJLu6vQ/WtQqldku4+c3p4QMnq/DzlHujOCAZPTEFCUV/DTlWirjgKn2gZYj9JH\ncHHhRkAFGVexueXhBhF/8pECgYBLFEYYAcbw8j7lW8SmdRdyaat+8oSQAIrhwP73\nMw50antNkW140pINeCo+dfU9l9tBgUeCUoVBawGvZfS2D+C8T6mDflU+aUQNDDJf\nAv4kWFNpekPw9e+VavE9qRf6ITMDw8Pk48NPjWftyIPxK6MhSa7uYaCtNnOLlZLV\nCffpsQKBgArvxL2X5xYnQpPNMMToFG7/px2sECN6rG1P6d7+8TVm670wzl3QmL6y\nGC/s+/oJCTgTf1RhZtIw25tb2n1pEC85jf/oZgGItL5kRcWixgjMro0MwKA1ZEKE\nIWeelAAFgcA8Ddd6dI9V3IOpNpXm7Vtui/8izwrMlzVwA1aLmpwe\n-----END RSA PRIVATE KEY-----",
        campaignIMSEndpoint : "https://ims-na1.adobelogin.com/s/ent_campaign_sdk"
    },
    target: {
        targetTenant : "adobeinternalpburg",
        targetClientID : "73c2d9702f954e9197128be313e6dd63",
        targetClientSecret : "955788bd-12c4-4cd5-82fd-d7edc6bca483",
        targetOrgID : "E118E1CE5444D9E40A4C98A5@AdobeOrg",
        targetTechnicalAccount : "c099b7ae-8b89-47d2-b342-87731de3417f@techacct.adobe.com",
        targetPEM : "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAq9cKmhgz2ICYeAUwzpnZ/X73o1p3lsew2Wj6x5PYIhpOoE2Z\n2cro6IVgCNHbbttoBWjUrL5h2GTBElTOQbYFh2Qr7WVclMXFuQ0ZjhmN1lIsSv5o\naCSqy6kqeINOMes17nz6CNNWK4XyDxCUJzDucA/jDpsZRBoeb2HyQZ+/oxvaA2xs\nvrOLPFltBusNpwvln+8CgYEApti87esDEPv4NfM9npXZTa+rYgXUO5hPMJwz\n+J5hmTktXQ1FuntqgDwtKtQti/oo8agMLU3g4WYS0yiIQgHEnmiFQ8m976IU7k+4\nnLUwftkwORrtKNxFjONPsLEwQgLFh2fozB2K0sqCarmym85IMxflpGxJv/fUAFWX\nJPfU5NMCgYEA13Q6+fVv/RC5o/Y0/KUOJBfQaR33u91OTPQJLlHm7yInw7zjTabN\nZqiV/t2X0YLAYiHi6zEqTldJVJSwZ+WZVtTeNRr2IxE6m5nla1JKj+oBlDK02idI\nyleyND+XMLrNwnIqRPJ0Vqkwguk9nFHizBTxzGCsfYMeEwp9ZEAOs1E=\n-----END RSA PRIVATE KEY-----",
        targetIMSEndpoint : "https://ims-na1.adobelogin.com/s/ent_marketing_sdk"
    }
}





    